---
name: content-optimization
description: This skill should be used when optimizing web content for SEO, user experience, and clarity. It provides workflows for evaluating content across eight dimensions (clarity, structure, accuracy, coverage, E-E-A-T, optimization, originality), executing targeted improvements, and generating SEO metadata. The skill supports both initial full-spectrum optimization and iterative category-focused enhancements with preservation logic to maintain quality gains.
license: MIT
---

# Content Optimization Skill

## Purpose

This skill transforms web content through a three-phase workflow: optimize (based on user goals), evaluate (score across eight dimensions), and enhance (generate SEO metadata). It enables both initial optimization and iterative improvements with preservation constraints.

## When to Use

Use this skill when:
- Optimizing existing content for better SEO performance
- Improving content clarity, structure, or accuracy
- Enhancing topic coverage or originality
- Generating meta descriptions for web content
- Iteratively improving content while maintaining quality in other areas

## Core Workflow

### Phase 1: Content Optimization

Construct the optimization prompt by layering components based on user needs:

1. **Start with Base Prompt** - Always include core rules for length, headings, focus, and quality standards (see `references/prompts.md`)
2. **Add Focused Improvement** (if iterative) - Append category-specific instructions for: clarity, structure, accuracy, coverage, E-E-A-T, optimization, or originality
3. **Inject User Data** (if applicable) - For accuracy/E-E-A-T/originality improvements, incorporate user-provided case studies, statistics, or unique angles
4. **Add Preservation Instructions** (if iterative) - Include current/target scores and constraint that no category drops >0.5 points

Transform the content using the complete layered prompt.

### Phase 2: Content Evaluation

After optimization, evaluate the output using the scoring prompt (see `references/scoring-guide.md`). Return JSON with scores (1-5) and explanations for:
- Clarity
- Structure
- Accuracy
- Coverage
- E-E-A-T (Expertise, Experience, Authoritativeness, Trustworthiness)
- Optimization (SEO)
- Originality
- Overall

### Phase 3: Meta Description Generation

Generate 3 SEO meta descriptions (150-160 characters each) based on optimized content. Include target keyword, action-oriented language. Return JSON with `primary`, `alternative1`, `alternative2`.

## Implementation Details

### Initial Optimization Flow
1. User provides: content, target topic, word range
2. Execute Phase 1 with Base Prompt only
3. Execute Phase 2 (evaluation)
4. Execute Phase 3 (meta descriptions)
5. Display scores and three meta options

### Iterative Improvement Flow
1. User selects category from scores (clarity, structure, accuracy, coverage, E-E-A-T, optimization, originality)
2. If category is accuracy/E-E-A-T/originality, collect user data (case studies, statistics, unique angles)
3. Execute Phase 1 with Base + Focused + User Data + Preservation
4. Execute Phase 2 (re-evaluate)
5. Display new scores and preserved categories
6. Allow user to apply changes or select another category

### Preservation Logic

When executing iterative improvements:
- Track original scores for all categories
- Append preservation instructions listing high-scoring categories (≥3.5/5)
- Enforce hard constraint: no category score drops >0.5 points
- If constraint violated, request revision

## Key References

- **Prompt Templates**: See `references/prompts.md` for complete Base Prompt and all Focused Improvement Prompts
- **Evaluation Criteria**: See `references/scoring-guide.md` for scoring framework and dimension guidelines
- **User Data Format**: User-provided content injected between Focused Improvement and Preservation blocks

## Best Practices

- Provide specific target topics (avoid vague subjects)
- Set realistic word ranges (200-2500 optimal)
- Supply original data when possible (improves originality/accuracy)
- Review high-scoring categories before iterating
- Focus iterative improvements on one category at a time
- Use preservation to maintain gains while improving weak areas

## Example: Iterative Accuracy Improvement

**Initial State**: 900-word content with Accuracy score 3/5

1. User clicks "Improve Accuracy"
2. System collects: 3 verified statistics, 2 source references, 1 date clarification
3. Execute optimization with Base + Accuracy Enhancement + User Data + Preservation
4. Result: Accuracy improves to 4.2/5, all preserved categories stay ≥3.5/5
5. User applies or selects next category to improve
