# Scoring Guide Reference

## JSON Response Format

Always return evaluation as JSON with this structure:

```json
{
  "clarity": {
    "score": 1-5,
    "explanation": "Assessment of sentence clarity, jargon removal, readability"
  },
  "structure": {
    "score": 1-5,
    "explanation": "Assessment of heading hierarchy, section organization, visual breaks"
  },
  "accuracy": {
    "score": 1-5,
    "explanation": "Assessment of factual precision, source references, data specificity"
  },
  "coverage": {
    "score": 1-5,
    "explanation": "Assessment of topic depth, FAQ completeness, aspect variety"
  },
  "eeat": {
    "score": 1-5,
    "explanation": "Assessment of expertise signals, authority, experience-based insights"
  },
  "optimization": {
    "score": 1-5,
    "explanation": "Assessment of keyword placement, schema markup, snippet optimization"
  },
  "originality": {
    "score": 1-5,
    "explanation": "Assessment of unique perspectives, original examples, fresh angles"
  },
  "overall": {
    "score": 1-5,
    "summary": "Holistic assessment and key strengths/weaknesses"
  }
}
```

## Scoring Scale

**5 - Excellent**
- All requirements met; exceeds expectations
- No noticeable gaps or issues
- Could be published as-is

**4 - Good**
- Requirements mostly met; minor areas for improvement
- Generally effective but could be polished
- One or two small refinements needed

**3 - Fair**
- Requirements partially met; noticeable gaps
- Functional but needs work
- Multiple areas need attention

**2 - Poor**
- Requirements minimally met; significant gaps
- Major issues present
- Requires substantial revision

**1 - Very Poor**
- Requirements not met; critical deficiencies
- Unusable in current state
- Needs complete rewrite

## Dimension Scoring Guidelines

### Clarity (1-5)

Evaluates readability and understandability.

**5**: Sentences average 15-20 words. Jargon replaced with plain language. Active voice throughout. Complex ideas broken into smaller chunks with examples. Technical terms defined on first use. No filler or redundancy.

**4**: Mostly clear with minor jargon. Average sentence length 20-25 words. Generally active voice. Most abstract concepts have examples. One or two technical terms undefined.

**3**: Some unclear passages. Mix of active/passive voice. Sentence length varies 15-35 words. Limited examples. Technical terms sometimes undefined.

**2**: Frequent unclear passages. Excessive jargon. Long, complex sentences (30+ words average). Minimal examples. Many undefined terms.

**1**: Largely incomprehensible. Dense jargon throughout. Passive voice predominates. No examples. Technical vocabulary not explained.

### Structure (1-5)

Evaluates organization, hierarchy, and visual breaks.

**5**: H2/H3 headings every 150-200 words. Logical flow: problem → solution → example → conclusion. Numbered lists for steps, bullets for features. Multiple tables/charts. Clear key takeaways section. Excellent visual hierarchy.

**4**: Mostly well-structured. Headings present but not perfectly spaced. Good logical flow with minor gaps. Some visual breaks present. Takeaways section present.

**3**: Basic structure present. Headings inconsistent or missing. Logical flow somewhat unclear. Limited visual breaks. No dedicated takeaways.

**2**: Weak structure. Headings sparse or missing. Poor logical flow. Few visual breaks. Difficult to scan.

**1**: No clear structure. No headings. Chaotic organization. No visual breaks. Impossible to scan.

### Accuracy (1-5)

Evaluates factual precision and data quality.

**5**: Specific statistics and percentages included. 2-3+ credible sources cited. All claims verifiable and current. Vague terms replaced with precise numbers. Time-sensitive info dated.

**4**: Most claims specific. 2+ sources cited. Minor vague statements remain. Mostly dated information.

**3**: Mix of specific and vague claims. 1-2 sources mentioned. Some unverifiable statements. Missing dates on time-sensitive info.

**2**: Many vague claims. Few sources cited. Several unverifiable statements. Outdated without notation.

**1**: Almost entirely vague or unverifiable. No sources. Contradictory claims. Severely outdated.

### Coverage (1-5)

Evaluates topic depth and breadth.

**5**: 3-5 FAQ questions addressing common user searches. Covers beginner, intermediate, advanced aspects. Includes pros/cons. Common mistakes section. Practical applications discussed. Feels comprehensive.

**4**: 3-4 FAQ questions. Covers most skill levels. Some pros/cons. Most practical aspects covered.

**3**: 2-3 FAQ questions. Covers one or two skill levels. Limited pros/cons. Some practical applications.

**2**: 1-2 FAQ questions. Covers one skill level. No pros/cons. Minimal applications.

**1**: No FAQ. Single skill level. No comparative analysis. No practical applications.

### E-E-A-T (1-5)

Evaluates expertise, experience, authoritativeness, trustworthiness.

**5**: Clear author credentials. 2-3+ authoritative sources. Original research or first-hand experience. "Last updated" + "Reviewed by" markers. Deep technical expertise evident.

**4**: Some credentials mentioned. 2+ authoritative sources. Some original insights. Update markers present. Good expertise depth.

**3**: Credentials mentioned. 1-2 sources cited. Minimal original insights. One marker missing. Moderate expertise.

**2**: Vague credentials. Generic sources. No original insights. No markers. Limited authority signals.

**1**: No credentials. No sources. No original insights. No trust signals. Highly suspect.

### Optimization (SEO) (1-5)

Evaluates SEO best practices.

**5**: Primary keyword in first 100 words. Keyword in 2-3 H2/H3 headings. Semantic variations throughout. 1-2% keyword density. Question-based headings. Schema markup suggested.

**4**: Keyword in first 150 words. Keyword in 1-2 headings. Most semantic variations. Near-optimal density. Most headings question-based.

**3**: Keyword in first 200 words. Keyword in 1 heading. Some semantic variations. Keyword density off. Few question-based headings.

**2**: Keyword beyond 200 words or missing from headings. Limited semantic variations. Keyword stuffing or too sparse. No question-based headings.

**1**: Keyword missing or only once. No semantic variations. Severe stuffing or complete absence. No search intent alignment.

### Originality (1-5)

Evaluates uniqueness and fresh perspectives.

**5**: Unique insights/perspectives not found elsewhere. Original examples or case studies. Fresh angles on common topics. Unique analogies. Personal commentary. Authentic voice.

**4**: Some unique perspectives. Mix of original and common examples. Generally fresh angle. Some unique analogies.

**3**: Limited unique content. Mostly standard examples. Generic angle. Common explanations.

**2**: Largely derivative. Generic examples. Recycled angle. Standard explanations.

**1**: Entirely generic. No original content. Common knowledge repeated. No distinguishing features.

### Overall (1-5)

Holistic assessment considering:
- How well all dimensions work together
- Readiness for publication
- Alignment with initial goals
- Strengths and weaknesses across all dimensions
- Whether iterative improvements are still needed

**5**: Excellent across all dimensions. Ready to publish. Achieves all goals. Compelling and professional.

**4**: Good overall. Minor polish needed. Mostly achieves goals. Professional quality.

**3**: Fair overall. Multiple improvements needed. Partially meets goals. Functional.

**2**: Poor overall. Significant work required. Barely meets goals. Needs revision.

**1**: Very poor. Unsuitable. Fails to meet goals. Requires rewrite.

## Scoring Tips

- Use dimension scores to identify which categories need improvement
- Overall score should reflect the average of all dimensions but consider that one weak dimension (e.g., clarity at 2/5) may lower overall even if others are high
- When evaluating for preservation (iterative runs), maintain consistent scoring standards—don't inflate scores to preserve categories
- Flag when a category's score dropped >0.5 points; this violates the preservation constraint
