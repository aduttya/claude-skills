# Prompt Templates Reference

## Base Prompt (Always Include)

```
**Core Structure Requirements:**
* **Length Control**: Keep total output between ${wordRangeFrom}-${wordRangeTo} words. Each section should not exceed 150 words unless it's the main content body.
* **Heading Format**: Use question-based H2/H3 headings followed by ONE direct answer sentence (20-30 words max) before expanding.
* **Information Architecture**: Use bullet points (3-5 per section), comparison tables, or numbered lists for scannability.

**Content Focus Rules:**
* **Stay on Topic**: Every sentence must directly relate to ${targetTopic}. Do not introduce tangential subjects or expanded narratives.
* **Strict Relevance Filter**: If brand guidelines are provided, mention product features ONLY when they directly answer the user's query. Limit promotional content to one brief mention (25 words max).
* **Main Topic Anchor**: Begin each section by restating how it connects to the primary topic.

**Answer Optimization:**
* **Front-Loading**: Place the primary answer/key insight in the first 75-100 words with a clear summary statement.
* **FAQ Section**: Include exactly 3-5 questions with answers of 50-70 words each. Questions must reflect actual user search patterns for ${targetTopic}.
* **Conversational Alignment**: Write for voice search queries (e.g., "How do I..." "What's the best way to..." "Why does...").

**Quality Standards:**
* **Factual Precision**: Include specific data, statistics, or examples. Avoid vague statements.
* **Recency Indicators**: Add "Last updated: [current date]" at the top and note when information applies (e.g., "As of Q4 2025...").
* **Authority Signals**: Reference 2-3 credible sources (e.g., "According to [Source]..." or "Research from [Authority] shows...") without full URLs unless specifically requested.

**Technical Enhancements:**
* Suggest appropriate schema markup: FAQ, HowTo, or Article.
* Use semantic keyword variations naturally (avoid keyword stuffing).

**Output Constraints:**
* Do NOT deviate into related but different topics
* Do NOT expand beyond the specified word count
* Do NOT prioritize brand messaging over user query intent
* Do NOT include information that requires web search to verify—stick to the provided content only
```

## Focused Improvement Prompts (Append for Iterative Runs)

### Clarity Enhancement
```
**FOCUSED IMPROVEMENT TARGET: CLARITY**

**Clarity Enhancement Instructions:**
* Use shorter sentences (15-20 words average)
* Replace jargon with plain language
* Add transition words between paragraphs (however, therefore, meanwhile)
* Use active voice instead of passive
* Break complex ideas into smaller chunks
* Add specific examples to illustrate abstract concepts
* Remove redundant phrases and filler words
* Define technical terms on first use
```

### Structure Enhancement
```
**FOCUSED IMPROVEMENT TARGET: STRUCTURE**

**Structure Enhancement Instructions:**
* Add clear H2/H3 subheadings every 150-200 words
* Use numbered lists for sequential steps (1, 2, 3)
* Use bullet points for related items or features
* Add a summary or key takeaways section
* Ensure logical flow: problem → solution → example → conclusion
* Include visual breaks with tables or comparison charts
* Group related information under thematic sections
```

### Accuracy Enhancement
```
**FOCUSED IMPROVEMENT TARGET: ACCURACY**

**Accuracy Enhancement Instructions:**
* Add specific statistics, data points, or percentages
* Include credible source references
* Replace vague terms with precise numbers
* Add date stamps for time-sensitive information
* Verify claims are factually consistent
* Remove speculative language; state facts clearly
```

### Coverage Enhancement
```
**FOCUSED IMPROVEMENT TARGET: COVERAGE**

**Coverage Enhancement Instructions:**
* Address common questions users have about ${targetTopic}
* Add FAQ section with 3-5 relevant questions
* Cover beginner, intermediate, and advanced aspects
* Include pros/cons or comparison sections
* Add "common mistakes" or "things to avoid"
* Expand on practical applications or use cases
```

### E-E-A-T Enhancement
```
**FOCUSED IMPROVEMENT TARGET: EEAT**

**E-E-A-T Enhancement Instructions:**
* Add author credentials or expertise signals
* Reference authoritative sources
* Include real experience-based insights or first-hand examples
* Use original data or research findings
* Add "Last updated" or "Reviewed by" markers
* Show depth of knowledge through detailed technical explanations
```

### SEO Optimization Enhancement
```
**FOCUSED IMPROVEMENT TARGET: OPTIMIZATION**

**SEO Optimization Enhancement Instructions:**
* Place primary keyword "${targetTopic}" in first 100 words
* Include keyword naturally in 2-3 H2/H3 headings
* Use semantic variations throughout
* Maintain keyword density between 1-2%
* Optimize for featured snippets
* Include question-based headings matching search intent
```

### Originality Enhancement
```
**FOCUSED IMPROVEMENT TARGET: ORIGINALITY**

**Originality Enhancement Instructions:**
* Add unique insights or perspectives not commonly found elsewhere
* Include original examples, case studies, or experiments
* Provide fresh angles on common topics
* Add personal observations or expert commentary
* Create unique analogies or explanations
* Avoid generic statements
```

## User Data Injection (For Iterative accuracy/E-E-A-T/originality)

```
**USER-PROVIDED ORIGINAL CONTENT (MUST INCORPORATE):**

Real Case Study/Experience:
"""
${userData.caseStudy}
"""

Verified Data Points:
"""
${userData.dataPoints}
"""

Unique Angle/Perspective:
"""
${userData.uniqueAngle}
"""

**CRITICAL INSTRUCTIONS:**
- Weave these REAL examples throughout the content naturally
- Use these statistics INSTEAD OF generic claims
- Frame all advice through the specific lens provided
- Reference this case study when discussing implementation
- Do NOT invent additional examples - use only what's provided above
- If you need additional examples, use hypothetical framing: "For instance, a company might..." rather than claiming it's real
```

## Preservation Instructions (For Iterative Runs)

```
**Current Score**: ${preserveData.currentScore}/5 → **Target**: ${preserveData.targetScore}/5

**CRITICAL: PRESERVE THESE HIGH-SCORING CATEGORIES:**
* ${p.category.toUpperCase()} (${p.score}/5) - Maintain current quality
[Repeat for each high-scoring category]

**ABSOLUTE CONSTRAINT**: No existing score should drop more than 0.5 points.
```

## Meta Description Generation Prompt

```
Create 3 compelling meta descriptions for content about ${cleanTopic}. 

Requirements: 
- 150-160 characters each
- Include target keyword naturally
- Action-oriented language
- One primary, two alternatives

Content to base descriptions on:
${cleanContent}

Respond with JSON: {"primary":"...","alternative1":"...","alternative2":"..."}
```

## Prompt Building Order

For iterative improvements, layer prompts in this order:
1. Base Prompt
2. Focused Improvement Prompt (if applicable)
3. User Data Injection (if applicable)
4. Preservation Instructions (if iterative)
5. Final: "Transform the content now: [content to optimize]"
